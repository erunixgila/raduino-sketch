## Installer la bibliothèque PinChangeInterrupt

Cette version de croquis (sketch) requiert la bibliothèque ["PinChangeInterrupt"](https://playground.arduino.cc/Main/PinChangeInterrupt) pour la gestion des interruptions.
C'est une librairie non-standard, c'est a dire qu'elle n'est pas installée par défaut. Executer les différentes étapes suivantes pour l'installer sur votre PC
Vous devez faire seulement ceci:

1. Aller dans 'Croquis' => 'Inclure une Bibliothèque' => 'Gérer les Bibliothèques...':

![libray-install1](installation_instructions/library-install1.PNG)

2. Le gestionnaire de bibliothèques devrait démarrer. Attendez jusqu'à ce que la liste complete des bibliothèque soit affichée:

![libray-install2](installation_instructions/library-install2.PNG)

3. Dans la fenêtre de recherche entrer "pinchangeinterrupt":

![libray-install3](installation_instructions/library-install3.PNG)

4. Sélectioner la bibliothèque nommée "PinChangeInterrupt by NicoHood", puis presser "installer":

![libray-install4](installation_instructions/library-install4.PNG)

5. Attendez que l'installation soit terminée et presser "fermer"

![libray-install5](installation_instructions/library-install5.PNG)
